<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Service Management</h1>
        <nav>
            <a href="index.php">Home</a> |
            <a href="add_service.php">Add New Service</a>
        </nav>
    </header>
    <main>
