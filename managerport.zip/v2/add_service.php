<?php include 'includes/db_connect.php'; ?>
<?php include 'templates/header.php'; ?>

<h2>Add New Service</h2>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $svr = $_POST['svr'];
    $namaservice = $_POST['namaservice'];
    $port = $_POST['port'];
    $dbname = $_POST['dbname'];
    $ip_tujuan = $_POST['ip_tujuan'];
    $port_tujuan = $_POST['port_tujuan'];
    $status = $_POST['status'];
    $keterangan = $_POST['keterangan'];

    $query = "INSERT INTO services (svr, namaservice, port, dbname, ip_tujuan, port_tujuan, status, keterangan)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->execute([$svr, $namaservice, $port, $dbname, $ip_tujuan, $port_tujuan, $status, $keterangan]);

    echo "<p>Service added successfully!</p>";
}
?>

<form method="post">
    <label>Server: <input type="text" name="svr" required></label><br>
    <label>Service Name: <input type="text" name="namaservice" required></label><br>
    <label>Port: <input type="number" name="port" required></label><br>
    <label>Dbname: <input type="number" name="dbname" required></label><br>
    <label>IP Tujuan: <input type="text" name="ip_tujuan" required></label><br>
    <label>Port Tujuan: <input type="number" name="port_tujuan" required></label><br>
    <label>Status: <input type="text" name="status" required></label><br>
    <label>Keterangan: <input type="text" name="keterangan" required></label><br>
    <input type="submit" value="Add Service">
</form>

<?php include 'templates/footer.php'; ?>
