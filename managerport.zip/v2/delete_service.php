<?php include 'includes/db_connect.php'; ?>

<?php
$id = $_GET['id'];
$query = "DELETE FROM services WHERE id = ?";
$stmt = $db->prepare($query);
$stmt->execute([$id]);

header('Location: index.php');
?>
