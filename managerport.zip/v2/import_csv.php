<?php
include 'includes/db_connect.php';
include 'templates/header.php'; // Memasukkan header

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
    $fileTmpPath = $_FILES['csv_file']['tmp_name'];
    $fileName = $_FILES['csv_file']['name'];
    $fileType = $_FILES['csv_file']['type'];

    if (($handle = fopen($fileTmpPath, 'r')) !== FALSE) {
        $header = fgetcsv($handle);
        $errors = [];
        $success = 0;
        $failed = 0;
        $existingData = [];

        while (($data = fgetcsv($handle)) !== FALSE) {
            $svr = $data[0];
            $namaservice = $data[1];
            $port = $data[2];
            $dbname = $data[3];
            $ip_tujuan = $data[4];
            $port_tujuan = $data[5];
            $status = $data[6];
            $keterangan = $data[7];

            // Check if the data already exists
            $checkQuery = "SELECT COUNT(*) FROM services WHERE svr = :svr AND namaservice = :namaservice AND port = :port ";
            $checkStmt = $db->prepare($checkQuery);
            $checkStmt->bindValue(':svr', $svr);
            $checkStmt->bindValue(':namaservice', $namaservice);
            $checkStmt->bindValue(':port', $port);
            $checkStmt->execute();
            $exists = $checkStmt->fetchColumn();

            if ($exists > 0) {
                $existingData[] = $data;
                continue;
            }

            $query = "INSERT INTO services (svr, namaservice, port, dbname, ip_tujuan, port_tujuan, status, keterangan) VALUES (:svr, :namaservice, :port, :dbname, :ip_tujuan, :port_tujuan, :status, :keterangan)";
            $stmt = $db->prepare($query);

            try {
                $stmt->bindValue(':svr', $svr);
                $stmt->bindValue(':namaservice', $namaservice);
                $stmt->bindValue(':port', $port);
                $stmt->bindValue(':dbname', $dbname);
                $stmt->bindValue(':ip_tujuan', $ip_tujuan);
                $stmt->bindValue(':port_tujuan', $port_tujuan);
                $stmt->bindValue(':status', $status);
                $stmt->bindValue(':keterangan', $keterangan);
                $stmt->execute();
                $success++;
            } catch (PDOException $e) {
                $errors[] = "Error inserting data for row: " . implode(',', $data) . " - " . $e->getMessage();
                $failed++;
            }
        }

        fclose($handle);
    } else {
        $errors[] = "Error opening the file.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import CSV</title>
</head>
<body>
    <h1>Import CSV</h1>

    <form action="import_csv.php" method="post" enctype="multipart/form-data">
        <label for="csv_file">Import CSV:</label>
        <input type="file" name="csv_file" id="csv_file" accept=".csv">
        <input type="submit" value="Import">
    </form>

    <?php if (isset($success) || isset($errors) || !empty($existingData)): ?>
        <h2>Import Results</h2>
        <?php if (isset($success)): ?>
            <p>Successfully imported <?php echo $success; ?> records.</p>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <p>Failed to import <?php echo $failed; ?> records:</p>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        <?php if (!empty($existingData)): ?>
            <p>The following records already exist in the database and were not imported:</p>
            <table border="1">
                <thead>
                    <tr>
                        <th>Server</th>
                        <th>Service Name</th>
                        <th>Port</th>
                        <th>Dbname</th>
                        <th>IP Tujuan</th>
                        <th>Port Tujuan</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($existingData as $data): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($data[0], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($data[1], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($data[2], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($data[3], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($data[4], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($data[5], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($data[6], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($data[7], ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?>

</body>
</html>
