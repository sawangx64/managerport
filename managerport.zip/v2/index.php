<?php include 'includes/db_connect.php'; ?>
<?php include 'templates/header.php'; ?>

<h2>List of Services</h2>

<!-- Form for Importing CSV -->
<a href="import_csv.php">Import CSV</a>
<a href="export_csv.php?<?php echo http_build_query($_GET); ?>">Export to CSV</a>

<!-- Form for Search, Limit, Sort -->
<form method="get" action="index.php">
    <label for="search">Search:</label>
    <input type="text" name="search" id="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">

    <label for="search_column">in:</label>
    <select name="search_column" id="search_column">
        <option value="svr" <?php if (isset($_GET['search_column']) && $_GET['search_column'] == 'svr') echo 'selected'; ?>>Server</option>
        <option value="namaservice" <?php if (isset($_GET['search_column']) && $_GET['search_column'] == 'namaservice') echo 'selected'; ?>>Service Name</option>
        <option value="port" <?php if (isset($_GET['search_column']) && $_GET['search_column'] == 'port') echo 'selected'; ?>>Port</option>
        <option value="dbaname" <?php if (isset($_GET['search_column']) && $_GET['search_column'] == 'dbname') echo 'selected'; ?>>Dbname</option>
        <option value="ip_tujuan" <?php if (isset($_GET['search_column']) && $_GET['search_column'] == 'ip_tujuan') echo 'selected'; ?>>IP Tujuan</option>
        <option value="port_tujuan" <?php if (isset($_GET['search_column']) && $_GET['search_column'] == 'port_tujuan') echo 'selected'; ?>>Port Tujuan</option>
        <option value="status" <?php if (isset($_GET['search_column']) && $_GET['search_column'] == 'status') echo 'selected'; ?>>Status</option>
        <option value="keterangan" <?php if (isset($_GET['search_column']) && $_GET['search_column'] == 'keterangan') echo 'selected'; ?>>Keterangaan</option>
    </select>

    <label for="limit">Show:</label>
    <select name="limit" id="limit">
        <option value="10" <?php if (isset($_GET['limit']) && $_GET['limit'] == 10) echo 'selected'; ?>>10</option>
        <option value="20" <?php if (isset($_GET['limit']) && $_GET['limit'] == 20) echo 'selected'; ?>>20</option>
        <option value="50" <?php if (isset($_GET['limit']) && $_GET['limit'] == 50) echo 'selected'; ?>>50</option>
        <option value="100" <?php if (isset($_GET['limit']) && $_GET['limit'] == 100) echo 'selected'; ?>>100</option>
    </select>

    <label for="sort_by">Sort by:</label>
    <select name="sort_by" id="sort_by">
        <option value="svr" <?php if (isset($_GET['sort_by']) && $_GET['sort_by'] == 'svr') echo 'selected'; ?>>Server</option>
        <option value="namaservice" <?php if (isset($_GET['sort_by']) && $_GET['sort_by'] == 'namaservice') echo 'selected'; ?>>Service Name</option>
        <option value="port" <?php if (isset($_GET['sort_by']) && $_GET['sort_by'] == 'port') echo 'selected'; ?>>Port</option>
        <option value="dbname" <?php if (isset($_GET['sort_by']) && $_GET['sort_by'] == 'dbname') echo 'selected'; ?>>Dbname</option>
        <option value="ip_tujuan" <?php if (isset($_GET['sort_by']) && $_GET['sort_by'] == 'ip_tujuan') echo 'selected'; ?>>IP Tujuan</option>
        <option value="port_tujuan" <?php if (isset($_GET['sort_by']) && $_GET['sort_by'] == 'port_tujuan') echo 'selected'; ?>>Port Tujuan</option>
        <option value="status" <?php if (isset($_GET['sort_by']) && $_GET['sort_by'] == 'status') echo 'selected'; ?>>Status</option>
        <option value="keterangan" <?php if (isset($_GET['sort_by']) && $_GET['sort_by'] == 'keterangan') echo 'selected'; ?>>Keterangan</option>
    </select>

    <label for="sort_order">Order:</label>
    <select name="sort_order" id="sort_order">
        <option value="ASC" <?php if (isset($_GET['sort_order']) && $_GET['sort_order'] == 'ASC') echo 'selected'; ?>>Ascending</option>
        <option value="DESC" <?php if (isset($_GET['sort_order']) && $_GET['sort_order'] == 'DESC') echo 'selected'; ?>>Descending</option>
    </select>

    <input type="submit" value="Apply">
</form>

<?php
// Set default values if not set in GET parameters
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'svr';
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$search_column = isset($_GET['search_column']) ? $_GET['search_column'] : 'svr';

// Modify the query to include search if a search term is provided
$query = "SELECT * FROM services WHERE $search_column LIKE :search ORDER BY $sort_by $sort_order LIMIT :limit";
$stmt = $db->prepare($query);
$stmt->bindValue(':search', '%' . $search . '%');
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<table border="1">
    <tr>
        <th><a href="index.php?sort_by=svr&sort_order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Server</a></th>
        <th><a href="index.php?sort_by=namaservice&sort_order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Service Name</a></th>
        <th><a href="index.php?sort_by=port&sort_order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Port</a></th>
        <th><a href="index.php?sort_by=dbname&sort_order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Dbname</a></th>
        <th><a href="index.php?sort_by=ip_tujuan&sort_order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">IP Tujuan</a></th>
        <th><a href="index.php?sort_by=port_tujuan&sort_order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Port Tujuan</a></th>
        <th><a href="index.php?sort_by=status&sort_order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Status</a></th>
        <th><a href="index.php?sort_by=keterangan&sort_order=<?php echo $sort_order === 'ASC' ? 'DESC' : 'ASC'; ?>">Keterangan</a></th>
        <th>Actions</th>
    </tr>

    <?php
    foreach ($result as $row) {
        echo "<tr>
            <td>{$row['svr']}</td>
            <td>{$row['namaservice']}</td>
            <td>{$row['port']}</td>
            <td>{$row['dbname']}</td>
            <td>{$row['ip_tujuan']}</td>
            <td>{$row['port_tujuan']}</td>
            <td>{$row['status']}</td>
            <td>{$row['keterangan']}</td>
            <td>
                <a href='edit_service.php?id={$row['id']}'>Edit</a> |
                <a href='delete_service.php?id={$row['id']}'>Delete</a>
            </td>
        </tr>";
    }
    ?>

</table>

<?php include 'templates/footer.php'; ?>
