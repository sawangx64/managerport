<?php include 'includes/db_connect.php'; ?>
<?php include 'templates/header.php'; ?>

<h2>Edit Service</h2>

<?php
$id = $_GET['id'];
$query = "SELECT * FROM services WHERE id = ?";
$stmt = $db->prepare($query);
$stmt->execute([$id]);
$service = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $svr = $_POST['svr'];
    $namaservice = $_POST['namaservice'];
    $port = $_POST['port'];
    $dbname = $_POST['dbname'];
    $ip_tujuan = $_POST['ip_tujuan'];
    $port_tujuan = $_POST['port_tujuan'];
    $status = $_POST['status'];
    $keterangan = $_POST['keterangan'];

    $query = "UPDATE services SET svr = ?, namaservice = ?, port = ?, dbname = ?, ip_tujuan = ?, port_tujuan = ?, status = ?, keterangan = ? WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$svr, $namaservice, $port, $dbname, $ip_tujuan, $port_tujuan, $status,  $keterangan, $id]);

    echo "<p>Service updated successfully!</p>";
}
?>

<form method="post">
    <label>Server: <input type="text" name="svr" value="<?php echo $service['svr']; ?>" required></label><br>
    <label>Service Name: <input type="text" name="namaservice" value="<?php echo $service['namaservice']; ?>" required></label><br>
    <label>Port: <input type="number" name="port" value="<?php echo $service['port']; ?>" required></label><br>
    <label>Dbname: <input type="text" name="dbname" value="<?php echo $service['dbname']; ?>" required></label><br>
    <label>IP Tujuan: <input type="text" name="ip_tujuan" value="<?php echo $service['ip_tujuan']; ?>" required></label><br>
    <label>Port Tujuan: <input type="number" name="port_tujuan" value="<?php echo $service['port_tujuan']; ?>" required></label><br>
    <label>Status: <input type="text" name="status" value="<?php echo $service['status']; ?>" required></label><br>
    <label>Keterangan: <input type="text" name="keterangan" value="<?php echo $service['keterangan']; ?>" required></label><br>
    <input type="submit" value="Update Service">
</form>

<?php include 'templates/footer.php'; ?>
