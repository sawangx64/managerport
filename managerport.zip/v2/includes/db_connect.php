<?php
$db = new PDO('sqlite:' . __DIR__ . '/../db/services.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Membuat tabel jika belum ada
$query = "CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY,
    svr TEXT NOT NULL,
    namaservice TEXT NOT NULL,
    port INTEGER NOT NULL,
    dbname INTEGER NOT NULL,
    ip_tujuan TEXT NOT NULL,
    port_tujuan INTEGER NOT NULL,
    status TEXT NOT NULL,
    keterangan TEXT NOT NULL
)";
$db->exec($query);
?>



