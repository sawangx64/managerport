<?php
include 'includes/db_connect.php';

// Get parameters from URL
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'svr';
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$search_column = isset($_GET['search_column']) ? $_GET['search_column'] : 'svr';

// Set headers for CSV export
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=services_export.csv');

$output = fopen('php://output', 'w');

// Output column headers
fputcsv($output, array('svr', 'namaservice', 'port', 'dbname', 'ip_tujuan', 'port_tujuan', 'status', 'keterangan'));

// Fetch and output rows from the database based on parameters
$query = "SELECT svr, namaservice, port, dbname, ip_tujuan, port_tujuan, status, keterangan FROM services WHERE $search_column LIKE :search ORDER BY $sort_by $sort_order LIMIT :limit";
$stmt = $db->prepare($query);
$stmt->bindValue(':search', '%' . $search . '%');
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->execute();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    // Filter out any rows with all empty values
    if (array_filter($row)) {
        fputcsv($output, $row);
    }
}

fclose($output);
exit();
?>
